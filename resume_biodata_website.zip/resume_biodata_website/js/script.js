$(function () {
  // Automatically update the copyright year.
  $("#year").text(new Date().getFullYear());

  // Mobile navigation menu.
  $(".menu-toggle").on("click", function () {
    const isOpen = $(".navigation").toggleClass("open").hasClass("open");
    $(this).attr("aria-expanded", isOpen);
  });

  // Print the resume or save it as a PDF using the browser print dialog.
  $("#print-resume").on("click", function () {
    window.print();
  });

  // The contact form prepares an email; it does not store visitor data.
  $("#contact-form").on("submit", function (event) {
    event.preventDefault();
    const name = $("#visitor-name").val().trim();
    const email = $("#visitor-email").val().trim();
    const message = $("#visitor-message").val().trim();
    const subject = encodeURIComponent("Website enquiry from " + name);
    const body = encodeURIComponent("From: " + name + " (" + email + ")\n\n" + message);
    $("#form-note").text("Opening your email application...");
    window.location.href = "mailto:youremail@example.com?subject=" + subject + "&body=" + body;
  });
});